import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app/app.dart';
import 'core/services/ads_service.dart';
import 'core/services/push_notifications.dart';
import 'app/app_state.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
    await PushNotifications().init();
  } catch (_) {
    // Firebase not configured; run offline.
  }
  final prefs = await SharedPreferences.getInstance();
  await AdsService.init();
  runApp(
    ProviderScope(
      overrides: [sharedPrefsProvider.overrideWithValue(prefs)],
      child: const TrinkApp(),
    ),
  );
}

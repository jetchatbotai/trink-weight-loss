import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../core/localization/app_strings.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../premium/premium_screen.dart';

class ChallengesScreen extends ConsumerStatefulWidget {
  const ChallengesScreen({super.key});

  @override
  ConsumerState<ChallengesScreen> createState() => _ChallengesScreenState();
}

class _ChallengesScreenState extends ConsumerState<ChallengesScreen> {
  List<dynamic> _challenges = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final raw = await rootBundle.loadString('assets/data/challenges_30d.json');
    setState(() => _challenges = jsonDecode(raw) as List);
  }

  @override
  Widget build(BuildContext context) {
    final ent = ref.watch(premiumProvider);
    if (!ent.isPremium) {
      return Scaffold(
        appBar: AppBar(title: Text(AppStrings.of(context).challenges)),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.lock, size: 48),
                const SizedBox(height: 12),
                const Text('Challenges are Premium.'),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: () => context.push('/premium'),
                  child: const Text('Go Premium'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final s = AppStrings.of(context);
    final lang = Localizations.localeOf(context).languageCode;

    return Scaffold(
      appBar: AppBar(title: Text(s.challenges)),
      body: _challenges.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: _challenges.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final c = _challenges[i] as Map<String, dynamic>;
                final title = (lang == 'tr') ? c['title_tr'] : c['title_en'];
                final subtitle = (lang == 'tr') ? c['subtitle_tr'] : c['subtitle_en'];
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.emoji_events),
                    title: Text(title),
                    subtitle: Text(subtitle),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => context.push('/challenges/${c['id']}'),
                  ),
                );
              },
            ),
    );
  }
}

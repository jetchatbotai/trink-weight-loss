import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../core/localization/app_strings.dart';
import '../../data/models/workout.dart';

class ChallengeDaysScreen extends StatefulWidget {
  const ChallengeDaysScreen({super.key, required this.challengeId});
  final String challengeId;

  @override
  State<ChallengeDaysScreen> createState() => _ChallengeDaysScreenState();
}

class _ChallengeDaysScreenState extends State<ChallengeDaysScreen> {
  Map<String, dynamic>? _challenge;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final raw = await rootBundle.loadString('assets/data/challenges_30d.json');
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    setState(() => _challenge = list.firstWhere((e) => e['id'] == widget.challengeId));
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final lang = Localizations.localeOf(context).languageCode;

    final c = _challenge;
    if (c == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final title = (lang == 'tr') ? c['title_tr'] : c['title_en'];
    final days = (c['days'] as List).cast<Map<String, dynamic>>();

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: days.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, i) {
          final d = days[i];
          final w = Workout.fromJson(d['workout'] as Map<String, dynamic>);
          return Card(
            child: ListTile(
              title: Text('${lang == 'tr' ? 'Gün' : 'Day'} ${d['day']}'),
              subtitle: Text(w.titleFor(lang)),
              trailing: FilledButton(
                onPressed: () => context.push('/workout/${w.id}', extra: w),
                child: Text(s.startWorkout),
              ),
            ),
          );
        },
      ),
    );
  }
}

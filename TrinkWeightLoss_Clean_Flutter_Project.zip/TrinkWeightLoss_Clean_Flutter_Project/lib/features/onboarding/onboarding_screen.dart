import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/app_state.dart';
import '../../core/localization/app_strings.dart';
import '../../core/utils/formatters.dart';
import '../../core/services/calorie_calculator.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final _age = TextEditingController();
  final _height = TextEditingController();
  final _weight = TextEditingController();

  String _goal = 'lose';
  String _level = 'beginner';
  String _equipment = 'none';

  @override
  void dispose() {
    _age.dispose();
    _height.dispose();
    _weight.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.onboardingTitle)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(s.onboardingSubtitle),
          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _age,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: s.age),
                  onChanged: (v) => _age.text = clampNumeric(v, maxLen: 2),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _height,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(labelText: s.heightCm),
                  onChanged: (v) => _height.text = clampNumeric(v, maxLen: 3),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _weight,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(labelText: s.weightKg),
            onChanged: (v) => _weight.text = v.replaceAll(RegExp(r'[^0-9\.]'), ''),
          ),

          const SizedBox(height: 16),
          _Chips(
            label: s.goal,
            items: [
              _Chip('lose', s.loseWeight),
              _Chip('maintain', s.maintain),
              _Chip('gain', s.gain),
            ],
            value: _goal,
            onChanged: (v) => setState(() => _goal = v),
          ),
          const SizedBox(height: 12),
          _Chips(
            label: s.activityLevel,
            items: [
              _Chip('beginner', s.beginner),
              _Chip('intermediate', s.intermediate),
              _Chip('advanced', s.advanced),
            ],
            value: _level,
            onChanged: (v) => setState(() => _level = v),
          ),
          const SizedBox(height: 12),
          _Chips(
            label: s.equipment,
            items: [
              _Chip('none', s.noEquipment),
              _Chip('dumbbells', s.dumbbells),
              _Chip('bands', s.bands),
            ],
            value: _equipment,
            onChanged: (v) => setState(() => _equipment = v),
          ),
          const SizedBox(height: 16),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Builder(builder: (context) {
                final age = int.tryParse(_age.text) ?? 25;
                final height = double.tryParse(_height.text) ?? 170;
                final weight = double.tryParse(_weight.text) ?? 70;
                final target = CalorieCalculator.calorieTarget(
                  age: age,
                  heightCm: height,
                  weightKg: weight,
                  activityLevel: _level,
                  goal: _goal,
                );
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.calorieTarget, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    Text('${target} kcal'),
                  ],
                );
              }),
            ),
          ),

          const SizedBox(height: 24),
          FilledButton(
            onPressed: () async {
              final age = int.tryParse(_age.text);
              final height = double.tryParse(_height.text);
              final weight = double.tryParse(_weight.text);
              if (age == null || height == null || weight == null) return;

              final profile = UserProfile(
                age: age,
                heightCm: height,
                weightKg: weight,
                goal: _goal,
                activityLevel: _level,
                equipment: _equipment,
              );

              await ref.read(userProfileProvider.notifier).save(profile);
              await ref.read(onboardingDoneProvider.notifier).setDone(true);
              if (context.mounted) context.go('/home');
            },
            child: Text(s.getStarted),
          ),
          const SizedBox(height: 12),
          Text(s.privacyNote, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

class _Chip {
  final String value;
  final String label;
  _Chip(this.value, this.label);
}

class _Chips extends StatelessWidget {
  const _Chips({
    required this.label,
    required this.items,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final List<_Chip> items;
  final String value;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: [
            for (final it in items)
              ChoiceChip(
                label: Text(it.label),
                selected: value == it.value,
                onSelected: (_) => onChanged(it.value),
              ),
          ],
        ),
      ],
    );
  }
}

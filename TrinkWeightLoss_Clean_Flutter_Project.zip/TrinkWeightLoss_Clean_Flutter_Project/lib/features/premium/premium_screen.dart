import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/app_state.dart';
import '../../app/providers.dart';
import '../../core/localization/app_strings.dart';
import '../../core/services/premium_entitlement.dart';

final premiumProvider = Provider<PremiumEntitlement>((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  return PremiumEntitlement(prefs);
});

class PremiumScreen extends ConsumerStatefulWidget {
  const PremiumScreen({super.key});

  @override
  ConsumerState<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends ConsumerState<PremiumScreen> {
  StreamSubscription? _sub;
  bool _loading = true;
  List products = [];

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    final ent = ref.read(premiumProvider);
    _sub = ent.purchaseStream.listen((purchases) async {
      await ent.handlePurchases(purchases);
      if (mounted) setState(() {});
    });

    try {
      products = await ent.loadProducts();
    } catch (_) {
      products = [];
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final ent = ref.watch(premiumProvider);

    return Scaffold(
      appBar: AppBar(title: Text(s.premium)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: Icon(ent.isPremium ? Icons.verified : Icons.lock),
              title: Text(ent.isPremium ? 'Premium active' : 'Upgrade to Premium'),
              subtitle: Text(ent.isPremium
                  ? 'All workouts unlocked • No ads'
                  : 'Unlock AI, challenges, meal plans, and remove ads'),
            ),
          ),
          const SizedBox(height: 12),

          if (_loading)
            const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator()))
          else if (products.isEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'Products not loaded yet. Create products in Play Console / App Store Connect:
'
                  '- premium_monthly
- premium_yearly

'
                  'You can still test UI and gating now.',
                ),
              ),
            )
          else
            for (final p in products)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Card(
                  child: ListTile(
                    title: Text(p.title ?? 'Premium'),
                    subtitle: Text(p.price ?? ''),
                    trailing: FilledButton(
                      onPressed: () async => ent.buy(p),
                      child: const Text('Buy'),
                    ),
                  ),
                ),
              ),

          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    await ent.restore();
                    if (mounted) setState(() {});
                  },
                  child: Text(s.restorePurchases),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  onPressed: () async {
                    // Demo toggle (for testing without store products)
                    await ent.setPremium(!ent.isPremium);
                    if (mounted) setState(() {});
                  },
                  child: Text(ent.isPremium ? 'Disable (demo)' : 'Enable (demo)'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'Note: Receipt validation should be implemented on a backend for production.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}

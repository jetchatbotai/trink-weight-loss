import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../app/app_state.dart';
import '../../core/localization/app_strings.dart';
import '../../core/services/calorie_calculator.dart';
import '../../core/services/meal_plan_generator.dart';

class MealPlanScreen extends ConsumerWidget {
  const MealPlanScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = AppStrings.of(context);
    final lang = Localizations.localeOf(context).languageCode;
    final profile = ref.watch(userProfileProvider);

    if (profile == null) {
      return const Scaffold(
        body: Center(child: Text('Complete onboarding first')),
      );
    }

    final target = CalorieCalculator.calorieTarget(
      age: profile.age,
      weightKg: profile.weightKg,
      heightCm: profile.heightCm,
      activityLevel: profile.activityLevel,
      goal: profile.goal,
    );

    final plan = MealPlanGenerator().generate(targetCalories: target, goal: profile.goal, mealsPerDay: 3);

    return Scaffold(
      appBar: AppBar(title: const Text('Meal plan')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: Text(s.calorieTarget),
              subtitle: Text('${plan.targetCalories} kcal'),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Macros', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 6),
                  Text('Protein: ${plan.proteinGrams}g'),
                  Text('Carbs: ${plan.carbsGrams}g'),
                  Text('Fat: ${plan.fatGrams}g'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          for (final m in plan.meals)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Card(
                child: ListTile(
                  title: Text(lang == 'tr' ? m.titleTr : m.titleEn),
                  subtitle: Text('${m.calories} kcal • P ${m.protein}g • C ${m.carbs}g • F ${m.fat}g'),
                ),
              ),
            ),
          Text(s.privacyNote, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

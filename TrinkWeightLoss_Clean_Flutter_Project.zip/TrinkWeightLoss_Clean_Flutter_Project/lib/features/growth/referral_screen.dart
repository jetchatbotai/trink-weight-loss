import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../app/app_state.dart';
import '../../core/localization/app_strings.dart';
import '../../core/services/referral_service.dart';

final referralServiceProvider = Provider<ReferralService>((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  return ReferralService(prefs);
});

class ReferralScreen extends ConsumerStatefulWidget {
  const ReferralScreen({super.key});

  @override
  ConsumerState<ReferralScreen> createState() => _ReferralScreenState();
}

class _ReferralScreenState extends ConsumerState<ReferralScreen> {
  final _code = TextEditingController();
  String? _message;

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final svc = ref.watch(referralServiceProvider);
    final myCode = svc.getMyCode();
    final points = svc.getRewardPoints();
    final used = svc.getUsedCode();

    return Scaffold(
      appBar: AppBar(title: const Text('Referral')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: const Text('Your code'),
              subtitle: Text(myCode),
              trailing: IconButton(
                icon: const Icon(Icons.copy),
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: myCode));
                  if (mounted) setState(() => _message = 'Copied!');
                },
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              title: const Text('Reward points'),
              subtitle: Text('$points'),
            ),
          ),
          const SizedBox(height: 16),
          Text(used == null ? 'Enter a friend code (once)' : 'You already used: $used'),
          const SizedBox(height: 8),
          TextField(
            controller: _code,
            decoration: const InputDecoration(labelText: 'Referral code'),
            enabled: used == null,
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: used == null
                ? () async {
                    final ok = await svc.applyCode(_code.text);
                    setState(() => _message = ok ? 'Applied! +100 points' : 'Invalid / already used');
                  }
                : null,
            child: const Text('Apply'),
          ),
          if (_message != null) ...[
            const SizedBox(height: 12),
            Text(_message!, style: Theme.of(context).textTheme.bodyMedium),
          ],
          const SizedBox(height: 20),
          Text(s.privacyNote, style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

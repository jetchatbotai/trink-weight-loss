import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/providers.dart';
import '../../core/localization/app_strings.dart';
import '../../data/models/workout.dart';

class WorkoutPlayerScreen extends ConsumerStatefulWidget {
  const WorkoutPlayerScreen({super.key, required this.workoutId});
  final String workoutId;

  @override
  ConsumerState<WorkoutPlayerScreen> createState() => _WorkoutPlayerScreenState();
}

class _WorkoutPlayerScreenState extends ConsumerState<WorkoutPlayerScreen> {
  Timer? _timer;
  int _stepIndex = 0;
  int _remaining = 0;
  bool _running = false;

  Workout? _overrideWorkout;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final state = GoRouterState.of(context);
    final extra = state.extra;
    if (extra is Workout) {
      _overrideWorkout = extra;
    }
  }

  void _startTimer(int seconds) {
    _timer?.cancel();
    setState(() {
      _remaining = seconds;
      _running = true;
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_remaining <= 1) {
        t.cancel();
        _next();
      } else {
        setState(() => _remaining -= 1);
      }
    });
  }

  void _next() {
    final w = _currentWorkout(ref);
    if (w == null) return;

    if (_stepIndex >= w.sequence.length - 1) {
      _timer?.cancel();
      setState(() => _running = false);
      if (mounted) _showComplete();
      return;
    }
    setState(() => _stepIndex += 1);
    final nextStep = w.sequence[_stepIndex];
    _startTimer(nextStep.seconds);
  }

  Workout? _currentWorkout(WidgetRef ref) {
    if (_overrideWorkout != null) return _overrideWorkout;
    final workoutsAsync = ref.read(workoutsProvider);
    Workout? w;
    workoutsAsync.whenData((list) {
      w = list.where((x) => x.id == widget.workoutId).firstOrNull;
    });
    return w;
  }

  void _showComplete() {
    final s = AppStrings.of(context);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(s.workoutComplete),
        content: Text(s.greatJob),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              context.pop();
            },
            child: Text(s.continueLabel),
          )
        ],
      ),
    );
  }

  void _toggleStart(Workout w) {
    if (!_running) {
      if (_remaining == 0) {
        _startTimer(w.sequence[_stepIndex].seconds);
      } else {
        _startTimer(_remaining);
      }
    } else {
      _timer?.cancel();
      setState(() => _running = false);
    }
  }

  int _estimateCalories(Workout w, Map<String, int> exCals) {
    int total = 0;
    for (final st in w.sequence) {
      if (st.type == 'exercise' && st.exerciseId != null) {
        total += (exCals[st.exerciseId!] ?? 6);
      }
    }
    return total;
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final lang = Localizations.localeOf(context).languageCode;

    final exercisesAsync = ref.watch(exercisesProvider);
    final workoutsAsync = ref.watch(workoutsProvider);

    return Scaffold(
      appBar: AppBar(title: Text(s.startWorkout)),
      body: exercisesAsync.when(
        data: (exercises) {
          final exMap = {for (final e in exercises) e.id: e};
          final calMap = {for (final e in exercises) e.id: e.estimatedCalories};

          Workout? w = _overrideWorkout;
          if (w == null) {
            w = workoutsAsync.maybeWhen(
              data: (list) => list.where((x) => x.id == widget.workoutId).firstOrNull,
              orElse: () => null,
            );
          }
          if (w == null) return const Center(child: CircularProgressIndicator());

          final step = w.sequence[_stepIndex];
          final isRest = step.type == 'rest';
          final ex = isRest ? null : exMap[step.exerciseId];

          final title = isRest ? s.rest : (ex?.nameFor(lang) ?? 'Exercise');
          final total = step.seconds;
          final remaining = (_remaining == 0 && !_running) ? total : _remaining;

          final estBurn = _estimateCalories(w, calMap);

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(child: Text(w.titleFor(lang), style: Theme.of(context).textTheme.titleLarge)),
                    const SizedBox(width: 8),
                    Chip(label: Text('${s.estBurn}: ${s.calories(estBurn)}')),
                  ],
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Text(title, style: Theme.of(context).textTheme.headlineSmall),
                        const SizedBox(height: 12),
                        Text(s.seconds(remaining), style: Theme.of(context).textTheme.displaySmall),
                        const SizedBox(height: 12),
                        LinearProgressIndicator(value: 1 - (remaining / total)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () => _toggleStart(w!),
                        icon: Icon(_running ? Icons.pause : Icons.play_arrow),
                        label: Text(_running ? s.pause : s.startWorkout),
                      ),
                    ),
                    const SizedBox(width: 12),
                    IconButton(onPressed: _next, icon: const Icon(Icons.skip_next), tooltip: s.next),
                  ],
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: ListView.builder(
                    itemCount: w.sequence.length,
                    itemBuilder: (context, i) {
                      final st = w.sequence[i];
                      final rest = st.type == 'rest';
                      final label = rest ? s.rest : (exMap[st.exerciseId]?.nameFor(lang) ?? 'Exercise');
                      return ListTile(
                        leading: Icon(i == _stepIndex ? Icons.radio_button_checked : Icons.circle_outlined),
                        title: Text(label),
                        trailing: Text(s.seconds(st.seconds)),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('Error: $e')),
      ),
    );
  }
}

extension _FirstOrNull<E> on Iterable<E> {
  E? get firstOrNull => isEmpty ? null : first;
}

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/providers.dart';
import '../../core/localization/app_strings.dart';

class ProgressTab extends ConsumerWidget {
  const ProgressTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = AppStrings.of(context);
    final repo = ref.watch(progressRepositoryProvider);
    final entries = repo.getEntries();

    return Scaffold(
      appBar: AppBar(
        title: Text(s.progress),
        actions: [
          IconButton(
            onPressed: () => context.push('/progress/add'),
            icon: const Icon(Icons.add),
            tooltip: s.addWeightEntry,
          ),
        ],
      ),
      body: entries.isEmpty
          ? Center(child: Text(s.noEntriesYet))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: SizedBox(
                      height: 220,
                      child: LineChart(
                        LineChartData(
                          titlesData: const FlTitlesData(show: false),
                          borderData: FlBorderData(show: false),
                          gridData: const FlGridData(show: false),
                          lineBarsData: [
                            LineChartBarData(
                              spots: [
                                for (int i = 0; i < entries.length; i++)
                                  FlSpot(i.toDouble(), entries[entries.length - 1 - i].weightKg),
                              ],
                              isCurved: true,
                              dotData: const FlDotData(show: true),
                              belowBarData: BarAreaData(show: true),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                for (final e in entries)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Card(
                      child: ListTile(
                        title: Text('${e.weightKg.toStringAsFixed(1)} kg'),
                        subtitle: Text('${e.date.year}-${e.date.month.toString().padLeft(2,'0')}-${e.date.day.toString().padLeft(2,'0')}'),
                      ),
                    ),
                  )
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push('/progress/add'),
        icon: const Icon(Icons.add),
        label: Text(s.addWeightEntry),
      ),
    );
  }
}

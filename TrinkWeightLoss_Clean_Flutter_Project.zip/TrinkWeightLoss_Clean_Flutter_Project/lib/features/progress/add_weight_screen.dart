import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/providers.dart';
import '../../core/localization/app_strings.dart';

class AddWeightScreen extends ConsumerStatefulWidget {
  const AddWeightScreen({super.key});

  @override
  ConsumerState<AddWeightScreen> createState() => _AddWeightScreenState();
}

class _AddWeightScreenState extends ConsumerState<AddWeightScreen> {
  final _weight = TextEditingController();
  DateTime _date = DateTime.now();

  @override
  void dispose() {
    _weight.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.addWeightEntry)),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _weight,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: s.currentWeight),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: Text('${s.date}: ${_date.year}-${_date.month.toString().padLeft(2,'0')}-${_date.day.toString().padLeft(2,'0')}')),
                TextButton(
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: context,
                      firstDate: DateTime(2020),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                      initialDate: _date,
                    );
                    if (picked != null) setState(() => _date = picked);
                  },
                  child: const Text('Pick'),
                )
              ],
            ),
            const Spacer(),
            FilledButton(
              onPressed: () async {
                final text = _weight.text.replaceAll(',', '.').trim();
                final w = double.tryParse(text);
                if (w == null || w <= 0) return;
                final repo = ref.read(progressRepositoryProvider);
                await repo.addEntry(date: _date, weightKg: w);
                if (context.mounted) context.pop();
              },
              child: Text(s.save),
            )
          ],
        ),
      ),
    );
  }
}

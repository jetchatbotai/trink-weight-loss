import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../app/providers.dart';
import '../../../core/localization/app_strings.dart';

class LibraryTab extends ConsumerWidget {
  const LibraryTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = AppStrings.of(context);
    final lang = Localizations.localeOf(context).languageCode;
    final exercisesAsync = ref.watch(exercisesProvider);

    return Scaffold(
      appBar: AppBar(title: Text(s.library)),
      body: exercisesAsync.when(
        data: (exercises) {
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: exercises.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final ex = exercises[i];
              return Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.directions_run)),
                  title: Text(ex.nameFor(lang)),
                  subtitle: Text('${ex.difficulty} • ${ex.category}'),
                  trailing: Text(s.calories(ex.estimatedCalories)),
                ),
              );
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('Error: $e')),
      ),
    );
  }
}

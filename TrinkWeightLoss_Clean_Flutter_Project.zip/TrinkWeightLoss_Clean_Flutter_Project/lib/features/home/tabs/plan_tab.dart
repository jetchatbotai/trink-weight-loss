import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/providers.dart';
import '../../../app/app_state.dart';
import '../../../core/localization/app_strings.dart';
import '../../../core/services/ad_banner.dart';
import '../../premium/premium_screen.dart';

class PlanTab extends ConsumerWidget {
  const PlanTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = AppStrings.of(context);
    final lang = Localizations.localeOf(context).languageCode;

    final workoutsAsync = ref.watch(workoutsProvider);
    final exercisesAsync = ref.watch(exercisesProvider);
    final profile = ref.watch(userProfileProvider);

    return Scaffold(
      appBar: AppBar(title: Text(s.todayPlan)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.auto_awesome),
              title: Text(lang == 'tr' ? 'AI antrenman üret' : 'Generate AI workout'),
              subtitle: Text(profile == null
                  ? (lang == 'tr' ? 'Önce onboarding tamamlayın' : 'Complete onboarding first')
                  : (lang == 'tr' ? 'Hedefe göre kişisel antrenman' : 'Personalized workout based on goal')),
              trailing: FilledButton(
                onPressed: (profile == null)
                    ? null
                    : () async {
                        final ent = ref.read(premiumProvider);
                        if (!ent.isPremium) {
                          if (context.mounted) context.push('/premium');
                          return;
                        }

                        final exercises = await ref.read(exercisesAsync.future);
                        final gen = ref.read(aiGeneratorProvider);
                        final workout = gen.generate(profile: profile, exercises: exercises, langCode: lang, targetMinutes: 15);

                        // Store in memory by using a special route: we pass via extra.
                        if (context.mounted) {
                          context.push('/workout/${workout.id}', extra: workout);
                        }
                      },
                child: const Text('AI'),
              ),
            ),
          ),
          const SizedBox(height: 12),
          workoutsAsync.when(
            data: (workouts) {
              return Column(
                children: [
                  for (final w in workouts)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Card(
                        child: ListTile(
                          title: Text(w.titleFor(lang)),
                          subtitle: Text(s.minutes(w.minutes)),
                          trailing: FilledButton(
                            onPressed: () => context.push('/workout/${w.id}'),
                            child: Text(s.startWorkout),
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
            loading: () => const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator())),
            error: (e, st) => Text('Error: $e'),
          ),
          const SizedBox(height: 24),
          const SizedBox(height: 8),
          const AdBanner(),
          const SizedBox(height: 16),
          exercisesAsync.when(
            data: (ex) => Text('${lang == 'tr' ? 'Egzersiz sayısı' : 'Exercises'}: ${ex.length}'),
            loading: () => const SizedBox.shrink(),
            error: (_, __) => const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}

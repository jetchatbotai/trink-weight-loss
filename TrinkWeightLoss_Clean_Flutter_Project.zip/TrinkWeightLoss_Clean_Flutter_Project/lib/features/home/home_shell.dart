import 'package:flutter/material.dart';
import '../../core/localization/app_strings.dart';
import 'tabs/plan_tab.dart';
import 'tabs/library_tab.dart';
import '../progress/progress_tab.dart';
import '../settings/settings_tab.dart';
import '../challenges/challenges_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final tabs = const [
      PlanTab(),
      LibraryTab(),
      ChallengesScreen(),
      ProgressTab(),
      SettingsTab(),
    ];

    return Scaffold(
      body: tabs[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.today), label: s.todayPlan),
          NavigationDestination(icon: const Icon(Icons.fitness_center), label: s.library),
          NavigationDestination(icon: const Icon(Icons.emoji_events), label: s.challenges),
          NavigationDestination(icon: const Icon(Icons.show_chart), label: s.progress),
          NavigationDestination(icon: const Icon(Icons.settings), label: s.settings),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../app/app_state.dart';
import '../../core/localization/app_strings.dart';
import '../premium/premium_screen.dart';

class SettingsTab extends ConsumerWidget {
  const SettingsTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = AppStrings.of(context);
    final locale = ref.watch(localeProvider);
    final ent = ref.watch(premiumProvider);

    Widget lockedTile({required String title, required String subtitle, required VoidCallback onTap}) {
      return Card(
        child: ListTile(
          title: Text(title),
          subtitle: Text(subtitle),
          trailing: Icon(ent.isPremium ? Icons.chevron_right : Icons.lock),
          onTap: ent.isPremium ? onTap : () => context.push('/premium'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(s.settings)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              title: Text(s.premium),
              subtitle: Text(ent.isPremium ? 'Active' : 'Unlock features'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.push('/premium'),
            ),
          ),
          const SizedBox(height: 12),

          Card(
            child: ListTile(
              title: Text(s.language),
              subtitle: Text(locale.languageCode == 'tr' ? 'Türkçe' : locale.languageCode.toUpperCase()),
              trailing: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: locale.languageCode,
                  items: const [
                    DropdownMenuItem(value: 'en', child: Text('English')),
                    DropdownMenuItem(value: 'tr', child: Text('Türkçe')),
                    DropdownMenuItem(value: 'es', child: Text('Español')),
                    DropdownMenuItem(value: 'pt', child: Text('Português')),
                    DropdownMenuItem(value: 'de', child: Text('Deutsch')),
                  ],
                  onChanged: (code) {
                    if (code == null) return;
                    ref.read(localeProvider.notifier).setLocale(Locale(code));
                  },
                ),
              ),
            ),
          ),

          const SizedBox(height: 12),
          lockedTile(
            title: 'Referral',
            subtitle: 'Invite friends, earn rewards',
            onTap: () => context.push('/growth/referral'),
          ),
          const SizedBox(height: 12),
          lockedTile(
            title: 'Meal plan',
            subtitle: 'Macros & meal structure',
            onTap: () => context.push('/growth/meal'),
          ),

          const SizedBox(height: 12),
          const Card(
            child: ListTile(
              title: Text('Firebase (optional)'),
              subtitle: Text('Add config files to enable login, sync, push.'),
            ),
          ),
        ],
      ),
    );
  }
}

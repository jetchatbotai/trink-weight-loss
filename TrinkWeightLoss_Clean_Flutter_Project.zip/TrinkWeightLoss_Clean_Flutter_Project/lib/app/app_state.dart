import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

final sharedPrefsProvider = Provider<SharedPreferences>((ref) {
  throw UnimplementedError('sharedPrefsProvider must be overridden in main()');
});

final localeProvider = StateNotifierProvider<LocaleController, Locale>((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  final code = prefs.getString('locale') ?? 'en';
  return LocaleController(prefs, Locale(code));
});

class LocaleController extends StateNotifier<Locale> {
  LocaleController(this._prefs, Locale initial) : super(initial);
  final SharedPreferences _prefs;

  Future<void> setLocale(Locale locale) async {
    state = locale;
    await _prefs.setString('locale', locale.languageCode);
  }
}

final onboardingDoneProvider = StateNotifierProvider<OnboardingDoneController, bool>((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  final done = prefs.getBool('onboarding_done') ?? false;
  return OnboardingDoneController(prefs, done);
});

class OnboardingDoneController extends StateNotifier<bool> {
  OnboardingDoneController(this._prefs, bool initial) : super(initial);
  final SharedPreferences _prefs;

  Future<void> setDone(bool value) async {
    state = value;
    await _prefs.setBool('onboarding_done', value);
  }
}

class UserProfile {
  final int age;
  final double heightCm;
  final double weightKg;
  final String goal; // lose|maintain|gain
  final String activityLevel; // beginner|intermediate|advanced
  final String equipment; // none|dumbbells|bands

  const UserProfile({
    required this.age,
    required this.heightCm,
    required this.weightKg,
    required this.goal,
    required this.activityLevel,
    required this.equipment,
  });

  Map<String, dynamic> toJson() => {
        'age': age,
        'heightCm': heightCm,
        'weightKg': weightKg,
        'goal': goal,
        'activityLevel': activityLevel,
        'equipment': equipment,
      };

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        age: (json['age'] as num).toInt(),
        heightCm: (json['heightCm'] as num).toDouble(),
        weightKg: (json['weightKg'] as num).toDouble(),
        goal: json['goal'] as String,
        activityLevel: json['activityLevel'] as String,
        equipment: json['equipment'] as String,
      );
}

final userProfileProvider = StateNotifierProvider<UserProfileController, UserProfile?>((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  final raw = prefs.getString('user_profile');
  final profile = (raw == null) ? null : UserProfile.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  return UserProfileController(prefs, profile);
});

class UserProfileController extends StateNotifier<UserProfile?> {
  UserProfileController(this._prefs, UserProfile? initial) : super(initial);
  final SharedPreferences _prefs;

  Future<void> save(UserProfile profile) async {
    state = profile;
    await _prefs.setString('user_profile', jsonEncode(profile.toJson()));
  }
}

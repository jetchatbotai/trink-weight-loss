import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/repositories/content_repository.dart';
import '../data/repositories/progress_repository.dart';
import '../data/sources/local_json_source.dart';
import '../core/services/ai_workout_generator.dart';
import 'app_state.dart';

final localJsonSourceProvider = Provider((ref) => LocalJsonSource());

final contentRepositoryProvider = Provider((ref) {
  return ContentRepository(ref.watch(localJsonSourceProvider));
});

final exercisesProvider = FutureProvider((ref) async {
  final repo = ref.watch(contentRepositoryProvider);
  return repo.loadExercises();
});

final workoutsProvider = FutureProvider((ref) async {
  final repo = ref.watch(contentRepositoryProvider);
  return repo.loadWorkouts();
});

final progressRepositoryProvider = Provider((ref) {
  final prefs = ref.watch(sharedPrefsProvider);
  return ProgressRepository(prefs);
});

final aiGeneratorProvider = Provider((ref) => AiWorkoutGenerator());

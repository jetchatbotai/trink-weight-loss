import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme/app_theme.dart';
import '../core/localization/app_strings.dart';
import 'app_state.dart';
import 'router.dart';

class TrinkApp extends ConsumerWidget {
  const TrinkApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(localeProvider);
    final onboardingDone = ref.watch(onboardingDoneProvider);
    final router = AppRouter.create(onboardingDone: onboardingDone);

    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      title: 'Trink Weight Loss',
      theme: AppTheme.darkNeon(),
      locale: locale,
      supportedLocales: AppStrings.supportedLocales,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      routerConfig: router,
    );
  }
}

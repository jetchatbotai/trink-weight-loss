import 'package:go_router/go_router.dart';
import '../features/onboarding/onboarding_screen.dart';
import '../features/home/home_shell.dart';
import '../features/workout/workout_player_screen.dart';
import '../features/progress/add_weight_screen.dart';
import '../features/challenges/challenges_screen.dart';
import '../features/challenges/challenge_days_screen.dart';
import '../features/growth/referral_screen.dart';
import '../features/growth/meal_plan_screen.dart';
import '../features/premium/premium_screen.dart';

class AppRouter {
  static GoRouter create({required bool onboardingDone}) {
    return GoRouter(
      initialLocation: onboardingDone ? '/home' : '/onboarding',
      routes: [
        GoRoute(path: '/onboarding', builder: (_, __) => const OnboardingScreen()),
        GoRoute(path: '/home', builder: (_, __) => const HomeShell()),
        GoRoute(
          path: '/workout/:id',
          builder: (_, state) => WorkoutPlayerScreen(workoutId: state.pathParameters['id']!),
        ),
        GoRoute(path: '/progress/add', builder: (_, __) => const AddWeightScreen()),
        GoRoute(path: '/growth/referral', builder: (_, __) => const ReferralScreen()),
        GoRoute(path: '/growth/meal', builder: (_, __) => const MealPlanScreen()),
        GoRoute(path: '/premium', builder: (_, __) => const PremiumScreen()),
        GoRoute(path: '/challenges', builder: (_, __) => const ChallengesScreen()),
        GoRoute(
          path: '/challenges/:id',
          builder: (_, state) => ChallengeDaysScreen(challengeId: state.pathParameters['id']!),
        ),
      ],
    );
  }
}

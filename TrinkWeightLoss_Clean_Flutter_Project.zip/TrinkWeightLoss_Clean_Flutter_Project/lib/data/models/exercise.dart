class Exercise {
  final String id;
  final String nameEn;
  final String nameTr;
  final String category; // chest, abs, legs, cardio, full_body, ...
  final String difficulty; // beginner, intermediate, advanced
  final int durationSeconds;
  final int estimatedCalories;

  const Exercise({
    required this.id,
    required this.nameEn,
    required this.nameTr,
    required this.category,
    required this.difficulty,
    required this.durationSeconds,
    required this.estimatedCalories,
  });

  factory Exercise.fromJson(Map<String, dynamic> json) => Exercise(
        id: json['id'] as String,
        nameEn: json['name_en'] as String,
        nameTr: json['name_tr'] as String,
        category: json['category'] as String,
        difficulty: json['difficulty'] as String,
        durationSeconds: (json['duration_seconds'] as num).toInt(),
        estimatedCalories: (json['estimated_calories'] as num).toInt(),
      );

  String nameFor(String lang) => lang == 'tr' ? nameTr : nameEn;
}

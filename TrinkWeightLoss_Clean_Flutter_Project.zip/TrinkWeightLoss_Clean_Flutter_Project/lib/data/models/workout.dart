class WorkoutStep {
  final String type; // exercise | rest
  final String? exerciseId;
  final int seconds;

  const WorkoutStep({required this.type, required this.seconds, this.exerciseId});

  factory WorkoutStep.fromJson(Map<String, dynamic> json) => WorkoutStep(
        type: json['type'] as String,
        exerciseId: json['exercise_id'] as String?,
        seconds: (json['seconds'] as num).toInt(),
      );

  Map<String, dynamic> toJson() => {
        'type': type,
        'exercise_id': exerciseId,
        'seconds': seconds,
      };
}

class Workout {
  final String id;
  final String titleEn;
  final String titleTr;
  final int minutes;
  final List<WorkoutStep> sequence;

  const Workout({
    required this.id,
    required this.titleEn,
    required this.titleTr,
    required this.minutes,
    required this.sequence,
  });

  factory Workout.fromJson(Map<String, dynamic> json) => Workout(
        id: json['id'] as String,
        titleEn: json['title_en'] as String,
        titleTr: json['title_tr'] as String,
        minutes: (json['minutes'] as num).toInt(),
        sequence: (json['sequence'] as List).map((e) => WorkoutStep.fromJson(e as Map<String, dynamic>)).toList(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title_en': titleEn,
        'title_tr': titleTr,
        'minutes': minutes,
        'sequence': sequence.map((e) => e.toJson()).toList(),
      };

  String titleFor(String lang) => lang == 'tr' ? titleTr : titleEn;
}

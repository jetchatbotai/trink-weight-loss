import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/weight_entry.dart';

class ProgressRepository {
  ProgressRepository(this._prefs);
  final SharedPreferences _prefs;

  static const _key = 'weight_entries';
  final _uuid = const Uuid();

  List<WeightEntry> getEntries() {
    final raw = _prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    final decoded = jsonDecode(raw);
    if (decoded is! List) return [];
    final entries = decoded.cast<Map<String, dynamic>>().map(WeightEntry.fromJson).toList();
    entries.sort((a, b) => b.date.compareTo(a.date));
    return entries;
  }

  Future<void> addEntry({required DateTime date, required double weightKg}) async {
    final entries = getEntries();
    entries.add(WeightEntry(id: _uuid.v4(), date: date, weightKg: weightKg));
    final encoded = jsonEncode(entries.map((e) => e.toJson()).toList());
    await _prefs.setString(_key, encoded);
  }
}

import '../models/exercise.dart';
import '../models/workout.dart';
import '../sources/local_json_source.dart';

class ContentRepository {
  ContentRepository(this._source);
  final LocalJsonSource _source;

  Future<List<Exercise>> loadExercises() async {
    final list = await _source.loadList('assets/data/exercises_500.json');
    return list.map(Exercise.fromJson).toList();
  }

  Future<List<Workout>> loadWorkouts() async {
    final list = await _source.loadList('assets/data/workouts.json');
    return list.map(Workout.fromJson).toList();
  }
}

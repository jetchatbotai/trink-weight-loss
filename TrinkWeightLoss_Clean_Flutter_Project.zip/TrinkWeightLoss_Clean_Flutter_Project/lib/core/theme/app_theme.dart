import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData darkNeon() {
    const bg = Color(0xFF0B0F1A);
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF00C2FF),
        brightness: Brightness.dark,
        surface: const Color(0xFF10172A),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF0B0F1A),
        elevation: 0,
      ),
      cardTheme: CardTheme(
        color: const Color(0xFF10172A),
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
    );
  }
}

import '../../core/services/premium_entitlement.dart';

class PremiumGate {
  static bool isLocked({required bool isPremium}) => !isPremium;
}

String clampNumeric(String input, {int maxLen = 4}) {
  final digits = input.replaceAll(RegExp(r'[^0-9]'), '');
  if (digits.length <= maxLen) return digits;
  return digits.substring(0, maxLen);
}

import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';

class AppStrings {
  AppStrings(this.locale);
  final Locale locale;

  static const supportedLocales = [Locale('en'), Locale('tr')];

  static AppStrings of(BuildContext context) {
    final locale = Localizations.localeOf(context);
    Intl.defaultLocale = locale.languageCode;
    return AppStrings(locale);
  }

  String get appTitle => Intl.message('Trink Weight Loss', name: 'appTitle');
  String get continueLabel => Intl.message('Continue', name: 'continue');
  String get getStarted => Intl.message('Get started', name: 'getStarted');
  String get save => Intl.message('Save', name: 'save');
  String get startWorkout => Intl.message('Start workout', name: 'startWorkout');
  String get todayPlan => Intl.message("Today's plan", name: 'todayPlan');
  String get library => Intl.message('Library', name: 'library');
  String get progress => Intl.message('Progress', name: 'progress');
  String get settings => Intl.message('Settings', name: 'settings');
  String get challenges => Intl.message('Challenges', name: 'challenges');
  String get language => Intl.message('Language', name: 'language');

  String get onboardingTitle => Intl.message('Your plan, built for you', name: 'onboardingTitle');
  String get onboardingSubtitle => Intl.message('Tell us a few details to personalize workouts.', name: 'onboardingSubtitle');
  String get age => Intl.message('Age', name: 'age');
  String get heightCm => Intl.message('Height (cm)', name: 'heightCm');
  String get weightKg => Intl.message('Weight (kg)', name: 'weightKg');
  String get goal => Intl.message('Goal', name: 'goal');
  String get loseWeight => Intl.message('Lose weight', name: 'loseWeight');
  String get maintain => Intl.message('Maintain', name: 'maintain');
  String get gain => Intl.message('Gain', name: 'gain');
  String get activityLevel => Intl.message('Activity level', name: 'activityLevel');
  String get beginner => Intl.message('Beginner', name: 'beginner');
  String get intermediate => Intl.message('Intermediate', name: 'intermediate');
  String get advanced => Intl.message('Advanced', name: 'advanced');
  String get equipment => Intl.message('Equipment', name: 'equipment');
  String get noEquipment => Intl.message('No equipment', name: 'noEquipment');
  String get dumbbells => Intl.message('Dumbbells', name: 'dumbbells');
  String get bands => Intl.message('Resistance bands', name: 'bands');

  String get pause => Intl.message('Pause', name: 'pause');
  String get resume => Intl.message('Resume', name: 'resume');
  String get next => Intl.message('Next', name: 'next');
  String get rest => Intl.message('Rest', name: 'rest');

  String minutes(int n) => Intl.message('$n min', name: 'minutes', args: [n]);
  String seconds(int n) => Intl.message('$n sec', name: 'seconds', args: [n]);
  String calories(int n) => Intl.message('$n kcal', name: 'calories', args: [n]);

  String get workoutComplete => Intl.message('Workout complete!', name: 'workoutComplete');
  String get greatJob => Intl.message('Great job — keep the streak going.', name: 'greatJob');

  String get addWeightEntry => Intl.message('Add weight entry', name: 'addWeightEntry');
  String get currentWeight => Intl.message('Current weight', name: 'currentWeight');
  String get date => Intl.message('Date', name: 'date');
  String get noEntriesYet => Intl.message('No entries yet.', name: 'noEntriesYet');

  String get calorieTarget => Intl.message('Daily calorie target', name: 'calorieTarget');
  String get estBurn => Intl.message('Estimated burn', name: 'estBurn');

  String get privacyNote => Intl.message('This app is not medical advice. Consult a professional if needed.', name: 'privacyNote');
}

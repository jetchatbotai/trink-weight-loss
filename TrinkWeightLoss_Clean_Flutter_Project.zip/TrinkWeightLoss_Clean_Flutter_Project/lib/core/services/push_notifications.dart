import 'package:firebase_messaging/firebase_messaging.dart';

class PushNotifications {
  final FirebaseMessaging _msg = FirebaseMessaging.instance;

  Future<void> init() async {
    // iOS permission prompt
    await _msg.requestPermission();
    // Token fetch (optional)
    await _msg.getToken();
  }
}

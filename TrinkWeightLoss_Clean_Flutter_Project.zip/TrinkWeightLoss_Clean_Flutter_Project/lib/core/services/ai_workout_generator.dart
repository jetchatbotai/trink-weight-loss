import 'dart:math';
import '../../data/models/exercise.dart';
import '../../data/models/workout.dart';
import '../../app/app_state.dart';

class AiWorkoutGenerator {
  final _rng = Random();

  /// Generates a simple personalized workout (offline, rule-based).
  Workout generate({
    required UserProfile profile,
    required List<Exercise> exercises,
    required String langCode,
    int targetMinutes = 15,
  }) {
    // Filter by equipment (MVP uses all "none" only; you can add equipment matching later)
    final pool = exercises;

    // Difficulty filter
    final allowed = switch (profile.activityLevel) {
      'beginner' => ['beginner'],
      'intermediate' => ['beginner', 'intermediate'],
      'advanced' => ['beginner', 'intermediate', 'advanced'],
      _ => ['beginner'],
    };

    final filtered = pool.where((e) => allowed.contains(e.difficulty)).toList();

    // Goal-based category weights
    final weights = <String, int>{
      'cardio': profile.goal == 'lose' ? 5 : 3,
      'abs': profile.goal == 'lose' ? 3 : 2,
      'legs': 3,
      'chest': 2,
      'full_body': profile.goal == 'lose' ? 4 : 3,
    };

    List<WorkoutStep> steps = [];
    int totalSeconds = 0;

    // Step pattern: exercise 30-45s + rest 15s
    final rest = profile.activityLevel == 'beginner' ? 20 : 15;

    final used = <String>{};

    while (totalSeconds < targetMinutes * 60) {
      final cat = _pickWeighted(weights);
      final candidates = filtered.where((e) => e.category == cat && !used.contains(e.id)).toList();
      if (candidates.isEmpty) {
        // fallback to any
        final any = filtered.where((e) => !used.contains(e.id)).toList();
        if (any.isEmpty) break;
        final ex = any[_rng.nextInt(any.length)];
        steps.add(WorkoutStep(type: 'exercise', seconds: _exerciseSeconds(profile), exerciseId: ex.id));
        used.add(ex.id);
      } else {
        final ex = candidates[_rng.nextInt(candidates.length)];
        steps.add(WorkoutStep(type: 'exercise', seconds: _exerciseSeconds(profile), exerciseId: ex.id));
        used.add(ex.id);
      }
      totalSeconds += steps.last.seconds;

      // rest
      steps.add(WorkoutStep(type: 'rest', seconds: rest));
      totalSeconds += rest;
    }

    // Trim last rest if too long
    if (steps.isNotEmpty && steps.last.type == 'rest') {
      steps.removeLast();
    }

    final minutes = (totalSeconds / 60).round().clamp(5, 45);

    return Workout(
      id: 'ai_${DateTime.now().millisecondsSinceEpoch}',
      titleEn: 'AI workout (${minutes} min)',
      titleTr: 'AI antrenman (${minutes} dk)',
      minutes: minutes,
      sequence: steps,
    );
  }

  int _exerciseSeconds(UserProfile profile) {
    return switch (profile.activityLevel) {
      'beginner' => 30,
      'intermediate' => 40,
      'advanced' => 45,
      _ => 30,
    };
  }

  String _pickWeighted(Map<String, int> w) {
    final total = w.values.fold<int>(0, (a, b) => a + b);
    var roll = _rng.nextInt(max(1, total));
    for (final e in w.entries) {
      roll -= e.value;
      if (roll < 0) return e.key;
    }
    return w.keys.first;
  }
}

import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

/// Simple referral starter.
/// In production: validate on backend + anti-fraud + deep links (Firebase Dynamic Links / Branch).
class ReferralService {
  ReferralService(this._prefs);
  final SharedPreferences _prefs;

  static const _myCodeKey = 'ref_my_code';
  static const _usedCodeKey = 'ref_used_code';
  static const _rewardKey = 'ref_reward_points';

  String getMyCode() {
    final existing = _prefs.getString(_myCodeKey);
    if (existing != null && existing.isNotEmpty) return existing;
    final code = const Uuid().v4().replaceAll('-', '').substring(0, 8).toUpperCase();
    _prefs.setString(_myCodeKey, code);
    return code;
  }

  String? getUsedCode() => _prefs.getString(_usedCodeKey);

  int getRewardPoints() => _prefs.getInt(_rewardKey) ?? 0;

  /// Apply someone else's referral code once.
  /// Offline starter: grants local points.
  /// Production: call your backend and verify install / purchase conditions.
  Future<bool> applyCode(String code) async {
    code = code.trim().toUpperCase();
    if (code.length < 6) return false;
    final already = _prefs.getString(_usedCodeKey);
    if (already != null && already.isNotEmpty) return false;

    await _prefs.setString(_usedCodeKey, code);
    await _prefs.setInt(_rewardKey, getRewardPoints() + 100); // 100 points starter
    return true;
  }
}

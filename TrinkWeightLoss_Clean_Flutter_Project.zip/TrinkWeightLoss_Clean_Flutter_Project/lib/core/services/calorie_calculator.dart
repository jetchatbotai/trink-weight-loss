class CalorieCalculator {
  /// Mifflin-St Jeor (rough estimate).
  /// We avoid gender for simplicity in MVP (can add later).
  /// Assumes average factor and returns TDEE estimate.
  static double bmr({required int age, required double weightKg, required double heightCm}) {
    return 10 * weightKg + 6.25 * heightCm - 5 * age + 5;
  }

  static double tdee({required double bmr, required String activityLevel}) {
    final factor = switch (activityLevel) {
      'beginner' => 1.2,
      'intermediate' => 1.375,
      'advanced' => 1.55,
      _ => 1.2,
    };
    return bmr * factor;
  }

  static int calorieTarget({
    required int age,
    required double weightKg,
    required double heightCm,
    required String activityLevel,
    required String goal, // lose | maintain | gain
  }) {
    final base = tdee(bmr: bmr(age: age, weightKg: weightKg, heightCm: heightCm), activityLevel: activityLevel);
    final delta = switch (goal) {
      'lose' => -500,
      'gain' => 300,
      _ => 0,
    };
    return (base + delta).round();
  }
}

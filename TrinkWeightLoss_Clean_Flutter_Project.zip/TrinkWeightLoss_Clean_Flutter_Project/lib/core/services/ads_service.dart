import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdsService {
  // Enable with: --dart-define=ADMOB_ENABLED=true
  static const enabled = bool.fromEnvironment('ADMOB_ENABLED', defaultValue: false);

  // Test banner unit id (safe). Replace with your real AdMob unit id.
  static const bannerUnitId = 'ca-app-pub-3940256099942544/6300978111';

  static Future<void> init() async {
    if (!enabled) return;
    await MobileAds.instance.initialize();
  }
}

import 'dart:async';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PremiumEntitlement {
  PremiumEntitlement(this._prefs);

  final SharedPreferences _prefs;
  final InAppPurchase _iap = InAppPurchase.instance;

  static const _key = 'is_premium';
  static const monthlyId = 'premium_monthly';
  static const yearlyId = 'premium_yearly';

  bool get isPremium => _prefs.getBool(_key) ?? false;

  Future<void> setPremium(bool v) async => _prefs.setBool(_key, v);

  Stream<List<PurchaseDetails>> get purchaseStream => _iap.purchaseStream;

  Future<List<ProductDetails>> loadProducts() async {
    final resp = await _iap.queryProductDetails({monthlyId, yearlyId});
    return resp.productDetails;
  }

  Future<void> buy(ProductDetails product) async {
    final purchaseParam = PurchaseParam(productDetails: product);
    await _iap.buyNonConsumable(purchaseParam: purchaseParam);
  }

  Future<void> restore() => _iap.restorePurchases();

  /// Demo entitlement handler:
  /// - marks premium for any purchased/restored non-consumable
  /// Production: verify receipts on backend.
  Future<void> handlePurchases(List<PurchaseDetails> purchases) async {
    for (final p in purchases) {
      if (p.status == PurchaseStatus.purchased || p.status == PurchaseStatus.restored) {
        await setPremium(true);
      }
      if (p.pendingCompletePurchase) {
        await _iap.completePurchase(p);
      }
    }
  }
}

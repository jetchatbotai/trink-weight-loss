class MealPlan {
  final int targetCalories;
  final int proteinGrams;
  final int carbsGrams;
  final int fatGrams;
  final List<Meal> meals;

  const MealPlan({
    required this.targetCalories,
    required this.proteinGrams,
    required this.carbsGrams,
    required this.fatGrams,
    required this.meals,
  });
}

class Meal {
  final String titleEn;
  final String titleTr;
  final int calories;
  final int protein;
  final int carbs;
  final int fat;

  const Meal({
    required this.titleEn,
    required this.titleTr,
    required this.calories,
    required this.protein,
    required this.carbs,
    required this.fat,
  });
}

/// Offline, rule-based meal plan generator (starter).
/// IMPORTANT: Not medical advice.
class MealPlanGenerator {
  MealPlan generate({
    required int targetCalories,
    required String goal, // lose|maintain|gain
    int mealsPerDay = 3,
  }) {
    // Macro defaults (simple):
    // Lose: higher protein, moderate carbs.
    final macro = switch (goal) {
      'lose' => (p: 0.30, c: 0.40, f: 0.30),
      'gain' => (p: 0.25, c: 0.50, f: 0.25),
      _ => (p: 0.25, c: 0.45, f: 0.30),
    };

    final protein = ((targetCalories * macro.p) / 4).round();
    final carbs = ((targetCalories * macro.c) / 4).round();
    final fat = ((targetCalories * macro.f) / 9).round();

    final perMeal = (targetCalories / mealsPerDay).round();
    final meals = <Meal>[
      Meal(
        titleEn: 'High-protein breakfast',
        titleTr: 'Yüksek proteinli kahvaltı',
        calories: perMeal,
        protein: (protein / mealsPerDay).round(),
        carbs: (carbs / mealsPerDay).round(),
        fat: (fat / mealsPerDay).round(),
      ),
      if (mealsPerDay >= 2)
        Meal(
          titleEn: 'Balanced lunch',
          titleTr: 'Dengeli öğle yemeği',
          calories: perMeal,
          protein: (protein / mealsPerDay).round(),
          carbs: (carbs / mealsPerDay).round(),
          fat: (fat / mealsPerDay).round(),
        ),
      if (mealsPerDay >= 3)
        Meal(
          titleEn: 'Light dinner',
          titleTr: 'Hafif akşam yemeği',
          calories: targetCalories - perMeal * 2,
          protein: protein - (protein / mealsPerDay).round() * 2,
          carbs: carbs - (carbs / mealsPerDay).round() * 2,
          fat: fat - (fat / mealsPerDay).round() * 2,
        ),
    ];

    return MealPlan(
      targetCalories: targetCalories,
      proteinGrams: protein,
      carbsGrams: carbs,
      fatGrams: fat,
      meals: meals,
    );
  }
}

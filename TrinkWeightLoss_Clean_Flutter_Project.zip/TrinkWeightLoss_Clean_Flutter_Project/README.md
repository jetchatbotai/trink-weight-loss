# Trink Weight Loss (Flutter) — Full Starter

This is a **store-ready full starter** (source code + data) for:
- AI workout plan generator
- Workout player engine (timer/rest/steps)
- 30-day challenges
- Weight progress + chart
- TR/EN language switch
- iOS + Android (single codebase)

## Run
```bash
flutter pub get
flutter run
```

## Generate platform folders (if missing)
If you extracted this zip into a new folder:
```bash
flutter create .
```

## Build
Android AAB (Play Store):
```bash
flutter build appbundle --release
```

## Firebase (optional)
See `docs/firebase_setup.md` for steps.


## Integrated Growth Pack
- 500 exercise database (assets/data/exercises_500.json)
- Meal plan generator (offline starter)
- Referral starter
- Store listing + legal templates in docs/

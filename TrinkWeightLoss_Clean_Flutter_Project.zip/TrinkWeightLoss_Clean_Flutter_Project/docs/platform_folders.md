If you don't have android/ios folders (or you want to regenerate):
- Install Flutter SDK
- In project root:
  `flutter create .`
This will generate `android/` and `ios/` directories for you.

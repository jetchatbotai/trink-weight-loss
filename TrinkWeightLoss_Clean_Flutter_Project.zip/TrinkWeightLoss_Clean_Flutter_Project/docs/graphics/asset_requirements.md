# Store Asset Requirements (Quick)

## Google Play
- App icon: 512x512 PNG (no transparency recommended)
- Feature graphic: 1024x500
- Screenshots: min 2, up to 8 (phone); 1080x1920 typical
- Promo video: YouTube URL (optional)

## App Store
- App icon: 1024x1024 PNG
- Screenshots: various sizes (6.7", 6.5", 5.5")

Tip:
- Icon should be symbol-only (no text) for readability.

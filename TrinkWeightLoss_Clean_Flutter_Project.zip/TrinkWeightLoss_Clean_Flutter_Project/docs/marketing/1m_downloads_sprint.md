# 1M Downloads Sprint (Global)

## Content engine (TikTok / Reels / Shorts)
- 3 videos/day for 30 days
- Formats:
  1) 10-minute fat burn (timer overlay)
  2) 30-day challenge day X (before/after style)
  3) “Do this at home” tutorial

CTA: "Download Trink Weight Loss"

## Influencer seeding
- 20 micro influencers (10k–100k)
- Pay per post + track link (UTM)

## Store metrics targets (first 14 days)
- 5,000 installs
- 300 ratings
- 4.6+ average
- D1 retention 25%+ (push reminders)

## Countries to start
Tier-2 high volume:
- Brazil, Mexico, Turkey, Indonesia, Philippines
Then expand:
- US, UK, Germany, Spain

## Conversion boosters
- 5 screenshots + 1 promo video
- Clear value props: AI plan + challenge + weight chart

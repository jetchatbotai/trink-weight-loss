# Monetization / Firebase flags

This project supports safe defaults:
- Runs offline if Firebase is not configured.
- Ads are disabled unless you enable a flag.

## Ads
Run with ads enabled:
flutter run --dart-define=ADMOB_ENABLED=true

## Premium gating
Premium is stored locally for demo.
Real validation should be added (server-side receipt validation).

## Firebase
Add:
- android/app/google-services.json
- ios/Runner/GoogleService-Info.plist

Then run normally.

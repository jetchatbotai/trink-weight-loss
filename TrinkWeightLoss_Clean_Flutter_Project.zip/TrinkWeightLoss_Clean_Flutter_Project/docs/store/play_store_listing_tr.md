# Google Play Listing (TR)

## Başlık (max 30)
Trink Weight Loss

## Kısa açıklama (max 80)
Evde 10–20 dk antrenmanlarla zayıfla: challenge, AI plan ve kilo takibi.

## Tam açıklama
Trink Weight Loss, kısa ve etkili ev antrenmanlarıyla yağ yakmana ve düzenli kalmana yardımcı olur.

✅ Ekipmansız antrenman  
✅ 10–20 dakikalık rutinler  
✅ 30 gün challenge (Karın / Yağ yakım / Squat)  
✅ AI antrenman üretici (kişisel)  
✅ Kilo takibi & grafik  

Uyarı: Tıbbi tavsiye değildir. Gerekirse uzmana danışın.

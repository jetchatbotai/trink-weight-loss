# Google Play Listing (EN)

## Title (max 30)
Trink Weight Loss

## Short description (max 80)
Lose weight at home with 10–20 min workouts, challenges, and progress tracking.

## Full description
Trink Weight Loss helps you burn fat and stay consistent with short, effective home workouts.

✅ No equipment workouts  
✅ 10–20 minute routines  
✅ 30-day challenges (Abs / Fat Burn / Squat)  
✅ AI workout generator (personalized)  
✅ Weight tracking & progress chart  

Start today and keep your streak going.

Disclaimer: Trink Weight Loss is not medical advice. Consult a professional if needed.

## Keywords (for ASO notes)
home workout, weight loss, fat burn, HIIT, abs workout, 30 day challenge

# App Store Listing (EN)

## Subtitle (max 30)
Home workouts & fat burn

## Promotional text (max 170)
Short workouts, AI plans, and 30-day challenges to help you stay consistent.

## Description
Same as Play Store full description (EN) + privacy policy link.

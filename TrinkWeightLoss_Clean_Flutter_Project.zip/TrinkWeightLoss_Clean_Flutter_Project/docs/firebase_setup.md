# Firebase setup (optional)

This project ships **without** Firebase config files.
To enable Firebase:

1) Create a Firebase project (Android+iOS apps).
2) Add config files:
   - Android: `android/app/google-services.json`
   - iOS: `ios/Runner/GoogleService-Info.plist`

3) Uncomment Firebase packages in `pubspec.yaml`, then:
```bash
flutter pub get
```

4) Add the Gradle / iOS steps from official Firebase Flutter docs.

Recommended:
- Analytics
- Crashlytics
- Auth
- Firestore
- Messaging (push)

> Keep secrets out of git.

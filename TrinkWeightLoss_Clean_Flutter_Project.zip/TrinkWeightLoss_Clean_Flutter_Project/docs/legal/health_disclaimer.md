# Health Disclaimer

This app does not provide medical advice.
If you experience pain, dizziness, or discomfort, stop and seek professional guidance.

# Terms of Use (Template)

Trink Weight Loss is for informational and fitness purposes only and is not medical advice.
Use at your own risk. Consult a professional if needed.

Subscriptions:
- Premium subscriptions renew unless canceled.
- Prices vary by country and store.

Contact: support@yourdomain.com

# Privacy Policy (Template)

Last updated: YYYY-MM-DD

Trink Weight Loss ("we") provides the app. This template must be reviewed by a lawyer.

## Data we may collect
- App usage analytics (if enabled)
- Account info (email) (if you add sign-in)
- Push notification token (if enabled)
- Weight entries you choose to store (local and/or cloud)

## How we use data
- Provide app features (sync, login)
- Improve performance (crash reports)
- Send reminders (push notifications)

## Sharing
We may share data with service providers (Firebase, analytics) as configured by you.

## Your choices
- Use the app offline without login (if supported)
- Delete your account (if you implement account deletion)
- Disable notifications

Contact: support@yourdomain.com

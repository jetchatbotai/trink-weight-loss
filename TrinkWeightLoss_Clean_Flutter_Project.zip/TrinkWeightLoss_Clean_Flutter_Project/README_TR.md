# Trink Weight Loss – Düzenli Flutter Proje Paketi

Bu paket, dağınık yüklenen dosyaların yerine **düzenli Flutter proje yapısı** ile hazırlanmıştır.

## Bu pakette neler var?
- `lib/` uygulama kodları
- `assets/` veri dosyaları
- `docs/` yayın ve kurulum dokümanları
- `test/` test klasörü
- `pubspec.yaml`
- `.github/workflows/android-apk.yml` (GitHub Actions ile APK üretme)

## Önemli not
Bu ortamda Flutter SDK olmadığı için gerçek `android/` ve `ios/` klasörleri burada üretilemedi.
Bunlar ilk çalıştırmada şu komutla oluşur:

```bash
flutter create .
```

Ardından:

```bash
flutter pub get
flutter build apk --release
```

## GitHub ile APK alma
1. Bu paketi zip'ten çıkar.
2. İçindeki tüm dosya ve klasörleri **repo köküne** yükle.
3. GitHub > Eylemler > APK oluştur
4. İş akışını çalıştır.
5. Workflow içinde önce `flutter create .` çalışacağı için `android/` ve `ios/` otomatik oluşacaktır.

## Eğer bilgisayar varsa
Proje klasöründe:

```bash
flutter create .
flutter pub get
flutter run
```

## Beklenen kök yapı
- `.github/`
- `assets/`
- `docs/`
- `lib/`
- `test/`
- `pubspec.yaml`
- `analysis_options.yaml`
- `README.md`
- `README_TR.md`
